/**
 * Main Application Module
 * Основная логика приложения
 */

class WebDSLCompiler {
    constructor() {
        this.api = window.mockAPI;
        this.syntaxHighlighter = window.syntaxHighlighter;
        this.modeSwitcher = window.modeSwitcher;
        
        // Элементы DOM
        this.codeEditor = document.getElementById('codeEditor');
        this.fileInputGrammar = document.getElementById('fileInputGrammar');
        this.fileInputProgram = document.getElementById('fileInputProgram');
        
        // Кнопки режима разработчика
        this.loadGrammarBtn = document.getElementById('loadGrammarBtn');
        this.generateParserBtn = document.getElementById('generateParserBtn');
        
        // Кнопки режима пользователя
        this.connectInterpreterBtn = document.getElementById('connectInterpreterBtn');
        this.loadProgramBtn = document.getElementById('loadProgramBtn');
        this.runProgramBtn = document.getElementById('runProgramBtn');
        
        // Кнопка RUN и её состояние
        this.runButtonText = this.runProgramBtn.querySelector('span');
        this.isRunning = false;
        
        // Элементы результатов
        this.resultsContent = document.getElementById('resultsContent');
        
        // Модальное окно AST
        this.astModal = document.getElementById('astModal');
        this.closeModalBtn = document.getElementById('closeModalBtn');
        
        this.init();
    }
    
    init() {
        // Инициализация обработчиков событий
        this.initEventListeners();
        
        // Загрузка начального состояния
        this.loadInitialState();
    }
    
    initEventListeners() {
        // Обработчики для режима разработчика
        this.loadGrammarBtn.addEventListener('click', () => this.loadGrammar());
        this.generateParserBtn.addEventListener('click', () => this.generateParser());
        
        // Обработчики для режима пользователя
        this.connectInterpreterBtn.addEventListener('click', () => this.connectInterpreter());
        this.loadProgramBtn.addEventListener('click', () => this.loadProgram());
        this.runProgramBtn.addEventListener('click', () => this.runProgram());
        
        // Обработчики файловых inputs
        this.fileInputGrammar.addEventListener('change', (e) => this.handleFileLoad(e, true));
        this.fileInputProgram.addEventListener('change', (e) => this.handleFileLoad(e, false));
        
        // Обработчики модального окна
        this.closeModalBtn.addEventListener('click', () => this.closeASTModal());
        
        // Закрытие модального окна при клике вне его
        window.addEventListener('click', (e) => {
            if (e.target === this.astModal) {
                this.closeASTModal();
            }
        });
        
        // Обработка нажатия клавиши Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.astModal.style.display === 'block') {
                this.closeASTModal();
            }
        });
    }
    
    loadInitialState() {
        // Загрузить пример грамматики при старте
        if (this.syntaxHighlighter) {
            this.syntaxHighlighter.highlightGrammar(this.codeEditor.value);
        }
    }
    
    // Загрузка грамматики
    loadGrammar() {
        this.fileInputGrammar.click();
    }
    
    // Генерация парсера
    async generateParser() {
        try {
            // Показать индикатор загрузки
            this.generateParserBtn.disabled = true;
            const originalText = this.generateParserBtn.innerHTML;
            this.generateParserBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Генерация...';
            
            // Вызвать моковый API
            const result = await this.api.generateParser();
            
            // Показать уведомление
            this.api.showNotification(result.message, 'success');
            
            // Показать результат
            this.showResult(result.message, 'success');
            
        } catch (error) {
            this.api.showNotification(`Ошибка: ${error.message}`, 'warning');
        } finally {
            // Восстановить кнопку
            this.generateParserBtn.disabled = false;
            this.generateParserBtn.innerHTML = originalText;
        }
    }
    
    // Подключение интерпретатора
    async connectInterpreter() {
        try {
            // Показать индикатор загрузки
            this.connectInterpreterBtn.disabled = true;
            const originalText = this.connectInterpreterBtn.innerHTML;
            this.connectInterpreterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Подключение...';
            
            // Вызвать моковый API
            const result = await this.api.connectInterpreter();
            
            // Показать уведомление
            this.api.showNotification(result.message, 'success');
            
            // Показать результат
            this.showResult(result.message, 'success');
            
            // Активировать кнопку RUN
            this.runProgramBtn.disabled = false;
            
        } catch (error) {
            this.api.showNotification(`Ошибка: ${error.message}`, 'warning');
        } finally {
            // Восстановить кнопку
            this.connectInterpreterBtn.disabled = false;
            this.connectInterpreterBtn.innerHTML = originalText;
        }
    }
    
    // Загрузка программы
    loadProgram() {
        this.fileInputProgram.click();
    }
    
    // Запуск программы
    async runProgram() {
        if (this.isRunning) return;
        
        try {
            // Установить состояние выполнения
            this.isRunning = true;
            this.runProgramBtn.disabled = true;
            this.runProgramBtn.classList.remove('btn--success');
            this.runProgramBtn.classList.add('btn--disabled');
            this.runButtonText.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Выполнение...';
            
            // Получить код программы из редактора
            const programCode = this.codeEditor.value;
            
            // Вызвать моковый API
            const result = await this.api.runProgram(programCode);
            
            // Показать уведомление
            this.api.showNotification(result.message, 'success');
            
            // Показать результат
            this.showResult(result.message, 'success');
            
            // Показать кнопку для скачивания output.json
            this.showDownloadLink();
            
            // Показать кнопку для просмотра AST
            this.showASTButton();
            
        } catch (error) {
            this.api.showNotification(`Ошибка выполнения: ${error.message}`, 'warning');
        } finally {
            // Восстановить состояние кнопки через 2 секунды
            setTimeout(() => {
                this.isRunning = false;
                this.runProgramBtn.disabled = false;
                this.runProgramBtn.classList.remove('btn--disabled');
                this.runProgramBtn.classList.add('btn--success');
                this.runButtonText.innerHTML = '▶ RUN';
            }, 2000);
        }
    }
    
    // Обработка загрузки файла
    async handleFileLoad(event, isGrammar) {
        const fileInput = event.target;
        
        try {
            // Показать индикатор загрузки
            const loadingMessage = isGrammar ? 'Загрузка грамматики...' : 'Загрузка программы...';
            this.api.showNotification(loadingMessage, 'info');
            
            // Загрузить файл через моковый API
            const content = await this.api.loadFile(fileInput, isGrammar);
            
            // Установить содержимое в редактор
            this.codeEditor.value = content;
            
            // Применить подсветку синтаксиса
            if (isGrammar && this.syntaxHighlighter) {
                this.syntaxHighlighter.highlightGrammar(content);
            }
            
            // Показать уведомление об успехе
            const fileName = fileInput.files[0].name;
            const successMessage = isGrammar 
                ? `Грамматика "${fileName}" загружена` 
                : `Программа "${fileName}" загружена`;
            
            this.api.showNotification(successMessage, 'success');
            
            // Показать результат
            this.showResult(successMessage, 'info');
            
        } catch (error) {
            this.api.showNotification(`Ошибка загрузки файла: ${error.message}`, 'warning');
        } finally {
            // Сбросить input
            fileInput.value = '';
        }
    }
    
    // Показать результат в панели результатов
    showResult(message, type = 'info') {
        if (!this.resultsContent) return;
        
        const resultItem = document.createElement('div');
        resultItem.className = `result-item result-item--${type}`;
        
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'warning') icon = 'exclamation-triangle';
        
        resultItem.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span>${message}</span>
        `;
        
        this.resultsContent.appendChild(resultItem);
        
        // Автоматическая прокрутка к результату
        resultItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    // Показать ссылку для скачивания output.json
    showDownloadLink() {
        if (!this.resultsContent) return;
        
        // Удалить старую ссылку, если есть
        const oldLink = document.querySelector('.download-link');
        if (oldLink && oldLink.parentNode === this.resultsContent) {
            this.resultsContent.removeChild(oldLink);
        }
        
        // Создать новую ссылку
        const downloadLink = document.createElement('a');
        downloadLink.className = 'download-link';
        downloadLink.href = '#';
        downloadLink.innerHTML = '<i class="fas fa-download"></i> output.json';
        
        // Обработчик клика для имитации скачивания
        downloadLink.addEventListener('click', (e) => {
            e.preventDefault();
            this.downloadOutputJSON();
        });
        
        this.resultsContent.appendChild(downloadLink);
    }
    
    // Имитация скачивания файла output.json
    downloadOutputJSON() {
        const outputJSON = this.api.createMockOutputFile();
        const blob = new Blob([outputJSON], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'output.json';
        document.body.appendChild(a);
        a.click();
        
        // Очистка
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
        
        this.api.showNotification('Файл output.json скачан', 'success');
    }
    
    // Показать кнопку для просмотра AST
    showASTButton() {
        if (!this.resultsContent) return;
        
        // Удалить старую кнопку, если есть
        const oldButton = document.querySelector('.ast-button');
        if (oldButton && oldButton.parentNode === this.resultsContent) {
            this.resultsContent.removeChild(oldButton);
        }
        
        // Создать новую кнопку
        const astButton = document.createElement('button');
        astButton.className = 'btn btn--primary ast-button';
        astButton.innerHTML = '<i class="fas fa-project-diagram"></i> Показать AST';
        
        // Обработчик клика для показа AST
        astButton.addEventListener('click', () => this.showASTModal());
        
        this.resultsContent.appendChild(astButton);
    }
    
    // Показать модальное окно с AST
    async showASTModal() {
        try {
            // Показать индикатор загрузки
            this.api.showNotification('Генерация AST...', 'info');
            
            // Вызвать моковый API для получения AST
            const result = await this.api.getAST();
            
            // Показать модальное окно
            this.astModal.style.display = 'block';
            
            // Прокрутить в начало модального окна
            const modalBody = this.astModal.querySelector('.modal__body');
            if (modalBody) {
                modalBody.scrollTop = 0;
            }
            
        } catch (error) {
            this.api.showNotification(`Ошибка генерации AST: ${error.message}`, 'warning');
        }
    }
    
    // Закрыть модальное окно с AST
    closeASTModal() {
        this.astModal.style.display = 'none';
    }
}

// Инициализация приложения после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.app = new WebDSLCompiler();
});