/**
 * Mode Switcher Module
 * Обработка переключения между режимами разработчика и пользователя
 */

class ModeSwitcher {
    constructor() {
        this.modeSelect = document.getElementById('modeSelect');
        this.developerActions = document.getElementById('developerActions');
        this.userActions = document.getElementById('userActions');
        this.editorTitle = document.getElementById('editorTitle');
        
        this.init();
    }
    
    init() {
        // Установить начальный режим
        this.switchMode(this.modeSelect.value);
        
        // Обработчик изменения режима
        this.modeSelect.addEventListener('change', (e) => {
            this.switchMode(e.target.value);
        });
    }
    
    switchMode(mode) {
        if (mode === 'developer') {
            // Показать действия разработчика, скрыть действия пользователя
            this.developerActions.style.display = 'block';
            this.userActions.style.display = 'none';
            this.editorTitle.textContent = 'Редактор грамматики';
            
            // Обновить статус редактора
            this.updateEditorStatus('Режим разработчика DSL: работа с грамматиками');
            
            // Очистить результаты предыдущего режима
            this.clearResults();
            
            // Загрузить пример грамматики
            this.loadExampleGrammar();
            
        } else if (mode === 'user') {
            // Показать действия пользователя, скрыть действия разработчика
            this.developerActions.style.display = 'none';
            this.userActions.style.display = 'block';
            this.editorTitle.textContent = 'Редактор DSL программы';
            
            // Обновить статус редактора
            this.updateEditorStatus('Режим пользователя DSL: написание и выполнение программ');
            
            // Очистить результаты предыдущего режима
            this.clearResults();
            
            // Загрузить пример программы
            this.loadExampleProgram();
        }
    }
    
    updateEditorStatus(statusText) {
        const editorStatus = document.getElementById('editorStatus');
        if (editorStatus) {
            editorStatus.textContent = statusText;
        }
    }
    
    clearResults() {
        const resultsContent = document.getElementById('resultsContent');
        if (resultsContent) {
            resultsContent.innerHTML = '';
        }
    }
    
    loadExampleGrammar() {
        // В реальной версии здесь будет загрузка из файла
        // В мок-версии просто очищаем редактор
        const editor = document.getElementById('codeEditor');
        editor.value = '// Загрузите файл грамматики (.rbnf) или напишите свою грамматику здесь\n\n' +
                      '// Пример структуры грамматики:\n' +
                      '// METABLOCK {\n' +
                      '//   name = "YourDSL"\n' +
                      '//   version = "1.0"\n' +
                      '// }\n' +
                      '// \n' +
                      '// KEY \n' +
                      '//   "func", "return", "if", "else"\n' +
                      '// \n' +
                      '// TERMINAL \n' +
                      '//   NUMBER: /[0-9]+(\\.[0-9]+)?/,\n' +
                      '//   ID: /[a-zA-Z_][a-zA-Z0-9_]*/\n' +
                      '// \n' +
                      '// NON-TERMINAL \n' +
                      '//   Program, Function, Statement, Expression\n' +
                      '// \n' +
                      '// RULES \n' +
                      '//   Program = Function*;\n' +
                      '//   Function = "func" ID "(" ")" "{" Statement* "}";';
        
        // Применить подсветку синтаксиса
        if (window.syntaxHighlighter) {
            window.syntaxHighlighter.highlightGrammar(editor.value);
        }
    }
    
    loadExampleProgram() {
        // В реальной версии здесь будет загрузка из файла
        // В мок-версии просто очищаем редактор
        const editor = document.getElementById('codeEditor');
        editor.value = '// Загрузите программу на DSL или напишите свою программу здесь\n\n' +
                      '// Пример программы на SimpleMathDSL:\n' +
                      'func main() {\n' +
                      '    return 42;\n' +
                      '}\n' +
                      '\n' +
                      'func calculate() {\n' +
                      '    return 10 + 5 * 2;\n' +
                      '}\n' +
                      '\n' +
                      'func greet(name) {\n' +
                      '    return "Hello, " + name;\n' +
                      '}';
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.modeSwitcher = new ModeSwitcher();
});