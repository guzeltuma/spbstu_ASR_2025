/**
 * Syntax Highlighter Module
 * Базовая подсветка синтаксиса для RBNF грамматик
 */

class SyntaxHighlighter {
    constructor() {
        this.keywords = ['KEY', 'TERMINAL', 'NON-TERMINAL', 'RULES', 'METABLOCK'];
        this.init();
    }
    
    init() {
        // Инициализация обработчиков событий для редактора
        const editor = document.getElementById('codeEditor');
        if (editor) {
            editor.addEventListener('input', () => {
                this.highlightGrammar(editor.value);
            });
            
            editor.addEventListener('blur', () => {
                this.highlightGrammar(editor.value);
            });
        }
    }
    
    highlightGrammar(text) {
        const preview = document.getElementById('codePreview');
        if (!preview) return;
        
        // Очищаем превью
        preview.innerHTML = '';
        
        // Разбиваем текст на строки
        const lines = text.split('\n');
        
        // Обрабатываем каждую строку
        lines.forEach((line, lineIndex) => {
            const lineElement = document.createElement('div');
            lineElement.className = 'code-line';
            
            // Проверяем, является ли строка пустой или комментарием
            if (line.trim() === '') {
                lineElement.innerHTML = '&nbsp;';
            } else if (line.trim().startsWith('//')) {
                lineElement.innerHTML = `<span class="hl-comment">${this.escapeHtml(line)}</span>`;
            } else {
                // Проверяем ключевые слова блоков
                let highlightedLine = this.escapeHtml(line);
                
                // Подсветка ключевых слов
                this.keywords.forEach(keyword => {
                    const regex = new RegExp(`\\b${keyword}\\b`, 'g');
                    highlightedLine = highlightedLine.replace(regex, `<span class="hl-${keyword.toLowerCase()}">${keyword}</span>`);
                });
                
                // Подсветка строк в кавычках
                highlightedLine = highlightedLine.replace(/"([^"]*)"/g, '<span class="hl-string">"$1"</span>');
                
                // Подсветка регулярных выражений
                highlightedLine = highlightedLine.replace(/\/([^\/]+)\//g, '<span class="hl-regex">/$1/</span>');
                
                // Подсветка чисел
                highlightedLine = highlightedLine.replace(/\b\d+\b/g, '<span class="hl-number">$&</span>');
                
                lineElement.innerHTML = highlightedLine;
            }
            
            preview.appendChild(lineElement);
        });
        
        // Показываем превью
        preview.style.display = 'block';
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Метод для подсветки DSL программ (можно расширить при необходимости)
    highlightDSL(text) {
        const preview = document.getElementById('codePreview');
        if (!preview) return;
        
        // В мок-версии просто показываем текст без особой подсветки
        preview.innerHTML = this.escapeHtml(text).replace(/\n/g, '<br>');
        preview.style.display = 'block';
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.syntaxHighlighter = new SyntaxHighlighter();
});