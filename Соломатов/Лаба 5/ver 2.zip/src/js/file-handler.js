/**
 * File Handler Module
 * Обработка загрузки и валидации файлов
 */

class FileHandler {
    constructor() {
        this.currentGrammarContent = '';
        this.currentProgramContent = '';
        
        this.init();
    }
    
    init() {
        // Инициализация обработчиков файлов
        this.setupFileInputs();
    }
    
    setupFileInputs() {
        const fileInputGrammar = document.getElementById('fileInputGrammar');
        const fileInputProgram = document.getElementById('fileInputProgram');
        
        if (fileInputGrammar) {
            fileInputGrammar.addEventListener('change', (e) => this.handleGrammarFile(e));
        }
        
        if (fileInputProgram) {
            fileInputProgram.addEventListener('change', (e) => this.handleProgramFile(e));
        }
    }
    
    async handleGrammarFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            const content = await this.readFileAsText(file);
            this.currentGrammarContent = content;
            
            // Устанавливаем содержимое в редактор
            const editor = document.getElementById('codeEditor');
            if (editor) {
                editor.value = content;
                
                // Обновляем нумерацию строк
                if (window.lineNumbers) {
                    window.lineNumbers.forceUpdate();
                }
                
                // Применяем подсветку
                if (window.syntaxHighlighter) {
                    window.syntaxHighlighter.highlightGrammar(content);
                }
                
                // Сбрасываем состояние ошибок
                editor.classList.remove('code-editor--error');
                
                // Логируем успешную загрузку
                if (window.logger) {
                    window.logger.addCompilationMessage(`Грамматика "${file.name}" загружена`, 'success');
                }
                
                // Показываем уведомление
                this.showNotification(`Грамматика "${file.name}" загружена`, 'success');
            }
            
        } catch (error) {
            console.error('Error reading grammar file:', error);
            this.showNotification(`Ошибка загрузки файла: ${error.message}`, 'error');
        }
        
        // Сбрасываем input
        event.target.value = '';
    }
    
    async handleProgramFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            const content = await this.readFileAsText(file);
            this.currentProgramContent = content;
            
            // Устанавливаем содержимое в редактор
            const editor = document.getElementById('codeEditor');
            if (editor) {
                editor.value = content;
                
                // Обновляем нумерацию строк
                if (window.lineNumbers) {
                    window.lineNumbers.forceUpdate();
                }
                
                // Логируем успешную загрузку
                if (window.logger) {
                    window.logger.addInterpretationMessage(`Программа "${file.name}" загружена`, 'success');
                }
                
                // Проверяем, нужно ли активировать кнопку RUN
                this.updateRunButtonState();
                
                // Показываем уведомление
                this.showNotification(`Программа "${file.name}" загружена`, 'success');
            }
            
        } catch (error) {
            console.error('Error reading program file:', error);
            this.showNotification(`Ошибка загрузки файла: ${error.message}`, 'error');
        }
        
        // Сбрасываем input
        event.target.value = '';
    }
    
    readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                resolve(e.target.result);
            };
            
            reader.onerror = () => {
                reject(new Error('Ошибка чтения файла'));
            };
            
            reader.readAsText(file);
        });
    }
    
    // Валидация структуры ZIP-архива интерпретатора
    validateInterpreterStructure(files) {
        const requiredFiles = [
            'grammar.py',
            'tokenizer.py', 
            'cst_builder.py',
            'semhandlers/__init__.py',
            'semhandlers/visitor.py'
        ];
        
        // В мок-версии всегда возвращаем true
        // В реальной версии здесь была бы проверка фактических файлов
        
        return {
            isValid: true,
            missingFiles: [],
            foundFiles: requiredFiles
        };
    }
    
    // Обновление состояния кнопки RUN
    updateRunButtonState() {
        const runButton = document.getElementById('runProgramBtn');
        if (!runButton) return;
        
        const editor = document.getElementById('codeEditor');
        if (!editor) return;
        
        const isProgramEmpty = !editor.value.trim();
        const isInterpreterConnected = window.userMode ? window.userMode.isInterpreterConnected : false;
        
        // Кнопка активна только если программа не пустая И интерпретатор подключен
        runButton.disabled = isProgramEmpty || !isInterpreterConnected;
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        
        notification.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        // Автоматическое скрытие
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.fileHandler = new FileHandler();
});