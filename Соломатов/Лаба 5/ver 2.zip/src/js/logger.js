/**
 * Logger Module
 * Управление логами компиляции и интерпретации
 */

class Logger {
    constructor() {
        this.compilationLog = document.getElementById('compilationLog');
        this.interpretationLog = document.getElementById('interpretationLog');
        this.compilationContainer = document.getElementById('compilationLogContainer');
        this.interpretationContainer = document.getElementById('interpretationLogContainer');
        
        this.init();
    }
    
    init() {
        // Инициализация логов
        this.clearCompilationLog();
        this.clearInterpretationLog();
    }
    
    // Методы для лога компиляции
    addCompilationMessage(message, type = 'info') {
        if (!this.compilationLog) return;
        
        const logLine = document.createElement('div');
        logLine.className = `log-line log-line--${type}`;
        
        let prefix = 'ℹ';
        if (type === 'error') prefix = '✗';
        if (type === 'success') prefix = '✓';
        
        logLine.textContent = `${prefix} ${message}`;
        this.compilationLog.appendChild(logLine);
        
        // Автопрокрутка к последнему сообщению
        this.compilationLog.scrollTop = this.compilationLog.scrollHeight;
    }
    
    clearCompilationLog() {
        if (this.compilationLog) {
            this.compilationLog.innerHTML = '';
            this.addCompilationMessage('Лог компиляции готов', 'info');
        }
    }
    
    // Методы для лога интерпретации
    addInterpretationMessage(message, type = 'info') {
        if (!this.interpretationLog) return;
        
        const logLine = document.createElement('div');
        logLine.className = `log-line log-line--${type}`;
        
        let prefix = '→';
        if (type === 'error') prefix = '✗';
        if (type === 'success') prefix = '✓';
        
        logLine.textContent = `${prefix} ${message}`;
        this.interpretationLog.appendChild(logLine);
        
        // Автопрокрутка к последнему сообщению
        this.interpretationLog.scrollTop = this.interpretationLog.scrollHeight;
    }
    
    clearInterpretationLog() {
        if (this.interpretationLog) {
            this.interpretationLog.innerHTML = '';
            this.addInterpretationMessage('Лог интерпретации готов', 'info');
        }
    }
    
    // Переключение видимости логов в зависимости от режима
    showCompilationLog() {
        if (this.compilationContainer) {
            this.compilationContainer.style.display = 'block';
        }
        if (this.interpretationContainer) {
            this.interpretationContainer.style.display = 'none';
        }
    }
    
    showInterpretationLog() {
        if (this.compilationContainer) {
            this.compilationContainer.style.display = 'none';
        }
        if (this.interpretationContainer) {
            this.interpretationContainer.style.display = 'block';
        }
    }
    
    // Метод для имитации процесса компиляции
    mockCompilationProcess() {
        this.addCompilationMessage('Начинаем проверку грамматики...', 'info');
        
        setTimeout(() => {
            this.addCompilationMessage('Проверяем наличие обязательных блоков...', 'info');
        }, 300);
        
        setTimeout(() => {
            this.addCompilationMessage('Анализируем синтаксические правила...', 'info');
        }, 600);
        
        setTimeout(() => {
            this.addCompilationMessage('Генерируем структуру интерпретатора...', 'info');
        }, 900);
    }
    
    // Метод для имитации процесса интерпретации
    mockInterpretationProcess() {
        this.addInterpretationMessage('Начинаем компилировать...', 'info');
        
        setTimeout(() => {
            this.addInterpretationMessage('Обращаемся к интерпретатору...', 'info');
        }, 500);
        
        setTimeout(() => {
            this.addInterpretationMessage('Вывод: return 0', 'info');
        }, 1000);
        
        setTimeout(() => {
            this.addInterpretationMessage('Программа выполнена успешно', 'success');
        }, 1500);
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.logger = new Logger();
});