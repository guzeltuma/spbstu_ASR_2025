/**
 * Developer Mode Module
 * Логика для режима разработчика DSL
 */

class DeveloperMode {
    constructor() {
        this.codeEditor = document.getElementById('codeEditor');
        this.generateParserBtn = document.getElementById('generateParserBtn');
        this.loadGrammarBtn = document.getElementById('loadGrammarBtn');
        
        this.init();
    }
    
    init() {
        if (this.generateParserBtn) {
            this.generateParserBtn.addEventListener('click', () => this.generateInterpreter());
        }
        
        if (this.loadGrammarBtn) {
            this.loadGrammarBtn.addEventListener('click', () => this.loadGrammar());
        }
        
        // Обработчик изменения текста в редакторе
        if (this.codeEditor) {
            this.codeEditor.addEventListener('input', () => this.onEditorChange());
        }
    }
    
    loadGrammar() {
        const fileInput = document.getElementById('fileInputGrammar');
        if (fileInput) {
            fileInput.click();
        }
    }
    
    onEditorChange() {
        // Сбрасываем состояние ошибок при изменении текста
        if (this.codeEditor) {
            this.codeEditor.classList.remove('code-editor--error');
        }
    }
    
    async generateInterpreter() {
        if (!this.codeEditor || !window.logger || !window.syntaxHighlighter || !window.zipGenerator) {
            return;
        }
        
        const grammarContent = this.codeEditor.value;
        
        // Проверяем наличие обязательных блоков
        const validation = window.syntaxHighlighter.validateBlocks(grammarContent);
        
        // Логируем начало процесса
        window.logger.clearCompilationLog();
        window.logger.mockCompilationProcess();
        
        // Имитируем задержку
        this.generateParserBtn.disabled = true;
        const originalText = this.generateParserBtn.innerHTML;
        this.generateParserBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Генерация...';
        
        setTimeout(async () => {
            if (!validation.hasAllBlocks) {
                // Ошибка: не все блоки присутствуют
                window.logger.addCompilationMessage(`Ошибка: отсутствуют блоки: ${validation.missingBlocks.join(', ')}`, 'error');
                
                // Визуальная обратная связь - красный фон редактора
                this.codeEditor.classList.add('code-editor--error');
                
                // Показываем уведомление
                this.showNotification(`Ошибка: отсутствуют блоки: ${validation.missingBlocks.join(', ')}`, 'error');
            } else {
                // Все блоки присутствуют
                window.logger.addCompilationMessage('✓ Все обязательные блоки присутствуют', 'success');
                window.logger.addCompilationMessage('✓ Грамматика валидна', 'success');
                
                // Генерируем интерпретатор
                window.logger.addCompilationMessage('Генерация файлов интерпретатора...', 'info');
                
                // Извлекаем имя интерпретатора
                const parserName = window.zipGenerator.extractParserName(grammarContent);
                
                // Создаем ZIP-архив
                const zipResult = await window.zipGenerator.generateAndDownloadZip(grammarContent);
                
                if (zipResult.success) {
                    window.logger.addCompilationMessage(`✓ Интерпретатор "${parserName}" успешно сгенерирован`, 'success');
                    
                    // Показываем кнопку для скачивания ZIP
                    const resultsContent = document.getElementById('resultsContent');
                    if (resultsContent) {
                        window.zipGenerator.createDownloadButton(resultsContent);
                    }
                    
                    // Показываем уведомление
                    this.showNotification(`Интерпретатор "${parserName}" сгенерирован`, 'success');
                } else {
                    window.logger.addCompilationMessage(`✗ Ошибка генерации: ${zipResult.error}`, 'error');
                    this.showNotification(`Ошибка генерации: ${zipResult.error}`, 'error');
                }
            }
            
            // Восстанавливаем кнопку
            this.generateParserBtn.disabled = false;
            this.generateParserBtn.innerHTML = originalText;
            
        }, 2000); // Имитация задержки генерации
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        
        notification.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        // Автоматическое скрытие
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.developerMode = new DeveloperMode();
});