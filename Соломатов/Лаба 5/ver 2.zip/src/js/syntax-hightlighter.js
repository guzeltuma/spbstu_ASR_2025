/**
 * Syntax Highlighter and Linter Module
 * Подсветка синтаксиса и проверка опечаток для RBNF грамматик
 */

class SyntaxHighlighter {
    constructor() {
        this.keywords = ['KEY', 'TERMINAL', 'NON-TERMINAL', 'RULES', 'METABLOCK'];
        this.keywordRegex = /\b(KEY|TERMINAL|NON\-TERMINAL|RULES|METABLOCK)\b/gi;
        this.blocksRegex = /^\s*(KEY|TERMINAL|NON\-TERMINAL|RULES|METABLOCK)\s*\{/gm;
        
        this.init();
    }
    
    init() {
        const editor = document.getElementById('codeEditor');
        if (editor) {
            editor.addEventListener('input', () => {
                const content = editor.value;
                this.highlightGrammar(content);
                this.checkSpelling(content);
            });
            
            // Начальная подсветка
            this.highlightGrammar(editor.value);
        }
    }
    
    highlightGrammar(text) {
        const preview = document.getElementById('codePreview');
        if (!preview) return;
        
        // Разбиваем текст на строки
        const lines = text.split('\n');
        let highlightedHTML = '';
        
        lines.forEach((line) => {
            if (line.trim() === '') {
                highlightedHTML += '<div>&nbsp;</div>';
            } else {
                // Экранируем HTML
                let escapedLine = this.escapeHtml(line);
                
                // Подсветка ключевых слов (жёлтый цвет)
                escapedLine = escapedLine.replace(this.keywordRegex, 
                    '<span class="hl-keyword">$&</span>');
                
                // Подсветка строк в кавычках
                escapedLine = escapedLine.replace(/"([^"]*)"/g, 
                    '<span class="hl-string">"$1"</span>');
                
                // Подсветка регулярных выражений
                escapedLine = escapedLine.replace(/\/([^\/]+)\//g, 
                    '<span class="hl-regex">/$1/</span>');
                
                // Подсветка чисел
                escapedLine = escapedLine.replace(/\b\d+\b/g, 
                    '<span class="hl-number">$&</span>');
                
                // Подсветка комментариев
                if (line.trim().startsWith('//')) {
                    escapedLine = `<span class="hl-comment">${escapedLine}</span>`;
                }
                
                highlightedHTML += `<div>${escapedLine}</div>`;
            }
        });
        
        preview.innerHTML = highlightedHTML;
        preview.style.display = 'block';
    }
    
    checkSpelling(text) {
        const preview = document.getElementById('codePreview');
        if (!preview) return;
        
        // Проверяем каждую строку на опечатки в ключевых словах
        const lines = text.split('\n');
        
        lines.forEach((line, lineIndex) => {
            const lineDiv = preview.children[lineIndex];
            if (!lineDiv) return;
            
            const words = line.split(/\s+/);
            let lineHTML = lineDiv.innerHTML;
            
            words.forEach(word => {
                const cleanWord = word.replace(/[^\w\-]/g, '');
                
                // Проверяем похожи ли слова на ключевые, но не точное совпадение
                if (this.isSimilarToKeyword(cleanWord) && !this.isExactKeyword(cleanWord)) {
                    const regex = new RegExp(`\\b${cleanWord}\\b`, 'g');
                    lineHTML = lineHTML.replace(regex, 
                        `<span class="spellcheck-error">${cleanWord}</span>`);
                }
            });
            
            lineDiv.innerHTML = lineHTML;
        });
    }
    
    isSimilarToKeyword(word) {
        if (!word || word.length < 3) return false;
        
        const upperWord = word.toUpperCase();
        
        // Проверяем похожесть на каждое ключевое слово
        return this.keywords.some(keyword => {
            // Простая проверка расстояния Левенштейна
            return this.levenshteinDistance(upperWord, keyword) <= 2;
        });
    }
    
    isExactKeyword(word) {
        const upperWord = word.toUpperCase();
        return this.keywords.includes(upperWord);
    }
    
    // Простая реализация расстояния Левенштейна
    levenshteinDistance(a, b) {
        if (a.length === 0) return b.length;
        if (b.length === 0) return a.length;
        
        const matrix = [];
        
        for (let i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }
        
        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1, // замена
                        matrix[i][j - 1] + 1,     // вставка
                        matrix[i - 1][j] + 1      // удаление
                    );
                }
            }
        }
        
        return matrix[b.length][a.length];
    }
    
    // Проверка наличия всех обязательных блоков
    validateBlocks(text) {
        const blocks = [];
        const lines = text.split('\n');
        
        lines.forEach(line => {
            const match = line.match(this.blocksRegex);
            if (match) {
                const blockName = match[1];
                if (!blocks.includes(blockName)) {
                    blocks.push(blockName);
                }
            }
        });
        
        return {
            hasAllBlocks: this.keywords.every(keyword => blocks.includes(keyword)),
            missingBlocks: this.keywords.filter(keyword => !blocks.includes(keyword)),
            foundBlocks: blocks
        };
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.syntaxHighlighter = new SyntaxHighlighter();
});