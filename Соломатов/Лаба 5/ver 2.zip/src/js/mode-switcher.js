/**
 * Mode Switcher Module
 * Обработка переключения между режимами разработчика и пользователя
 */

class ModeSwitcher {
    constructor() {
        this.modeSelect = document.getElementById('modeSelect');
        this.developerActions = document.getElementById('developerActions');
        this.userActions = document.getElementById('userActions');
        this.editorTitle = document.getElementById('editorTitle');
        this.editorStatus = document.getElementById('editorStatus');
        this.codeEditor = document.getElementById('codeEditor');
        
        this.init();
    }
    
    init() {
        // Установить начальный режим
        this.switchMode(this.modeSelect.value);
        
        // Обработчик изменения режима
        this.modeSelect.addEventListener('change', (e) => {
            this.switchMode(e.target.value);
        });
        
        // Обработчик изменения текста в редакторе
        if (this.codeEditor) {
            this.codeEditor.addEventListener('input', () => {
                if (this.modeSelect.value === 'user' && window.userMode) {
                    window.userMode.updateRunButtonState();
                }
            });
        }
    }
    
    switchMode(mode) {
        if (mode === 'developer') {
            // Показать действия разработчика, скрыть действия пользователя
            this.developerActions.style.display = 'block';
            this.userActions.style.display = 'none';
            this.editorTitle.textContent = 'Редактор грамматики';
            this.editorStatus.textContent = 'Режим разработчика DSL: работа с грамматиками';
            
            // Показать лог компиляции, скрыть лог интерпретации
            if (window.logger) {
                window.logger.showCompilationLog();
                window.logger.clearCompilationLog();
            }
            
            // Очистить результаты предыдущего режима
            this.clearResults();
            
            // Сбросить состояние редактора
            this.resetEditorForDeveloper();
            
            // Обновить состояние интерпретатора
            if (window.userMode) {
                window.userMode.isInterpreterConnected = false;
                window.userMode.connectInterpreterBtn.disabled = false;
                window.userMode.connectInterpreterBtn.innerHTML = '<i class="fas fa-plug"></i> Подключить DSL-интерпретатор';
                window.userMode.connectInterpreterBtn.classList.remove('btn--success');
                window.userMode.connectInterpreterBtn.classList.add('btn--primary');
            }
            
        } else if (mode === 'user') {
            // Показать действия пользователя, скрыть действия разработчика
            this.developerActions.style.display = 'none';
            this.userActions.style.display = 'block';
            this.editorTitle.textContent = 'Редактор DSL программы';
            this.editorStatus.textContent = 'Режим пользователя DSL: написание и выполнение программ';
            
            // Показать лог интерпретации, скрыть лог компиляции
            if (window.logger) {
                window.logger.showInterpretationLog();
                window.logger.clearInterpretationLog();
            }
            
            // Очистить результаты предыдущего режима
            this.clearResults();
            
            // Сбросить состояние редактора
            this.resetEditorForUser();
            
            // Обновить состояние кнопки RUN
            if (window.userMode) {
                window.userMode.updateRunButtonState();
            }
        }
    }
    
    clearResults() {
        const resultsContent = document.getElementById('resultsContent');
        if (resultsContent) {
            resultsContent.innerHTML = '';
        }
    }
    
    resetEditorForDeveloper() {
        if (!this.codeEditor) return;
        
        // Сбросить состояние ошибок
        this.codeEditor.classList.remove('code-editor--error');
        
        // Если редактор пустой, загрузить пример грамматики
        if (!this.codeEditor.value.trim()) {
            this.loadExampleGrammar();
        }
        
        // Обновить нумерацию строк
        if (window.lineNumbers) {
            window.lineNumbers.forceUpdate();
        }
    }
    
    resetEditorForUser() {
        if (!this.codeEditor) return;
        
        // Если редактор пустой, загрузить пример программы
        if (!this.codeEditor.value.trim()) {
            this.loadExampleProgram();
        }
        
        // Обновить нумерацию строк
        if (window.lineNumbers) {
            window.lineNumbers.forceUpdate();
        }
    }
    
    loadExampleGrammar() {
        const exampleGrammar = `METABLOCK {
    name = "SimpleMathDSL"
    version = "1.0"
}

KEY 
    "func", "return", "if", "else"


TERMINAL 
    NUMBER: /[0-9]+(\\.[0-9]+)?/,
    ID: /[a-zA-Z_][a-zA-Z0-9_]*/,
    STRING: /"[^"]*"/


NON-TERMINAL 
    Program, Function, Statement, Expression


RULES 
    Program = Function*;
    Function = "func" ID "(" ")" "{" Statement* "}";
    Statement = "return" Expression ";";
    Expression = NUMBER | ID;`;
        
        this.codeEditor.value = exampleGrammar;
        
        // Применить подсветку синтаксиса
        if (window.syntaxHighlighter) {
            window.syntaxHighlighter.highlightGrammar(exampleGrammar);
        }
    }
    
    loadExampleProgram() {
        const exampleProgram = `// Пример программы на SimpleMathDSL

func main() {
    return 42;
}

func calculate() {
    return 10 + 5 * 2;
}

func greet(name) {
    return "Hello, " + name;
}`;
        
        this.codeEditor.value = exampleProgram;
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.modeSwitcher = new ModeSwitcher();
});