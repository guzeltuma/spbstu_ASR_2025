

class MockAPI {
    constructor() {
        this.currentParserName = 'yourtool';
        this.isInterpreterConnected = false;
        this.isProgramLoaded = false;
        this.programOutput = null;
    }
    
    // Имитация загрузки файла
    loadFile(fileInput, isGrammar = true) {
        return new Promise((resolve, reject) => {
            if (!fileInput.files || fileInput.files.length === 0) {
                reject(new Error('Файл не выбран'));
                return;
            }
            
            const file = fileInput.files[0];
            const reader = new FileReader();
            
            reader.onload = (e) => {
                const content = e.target.result;
                
                // Имитация задержки загрузки
                setTimeout(() => {
                    if (isGrammar) {
                        // Извлекаем имя парсера из METABLOCK
                        this.extractParserName(content);
                    } else {
                        this.isProgramLoaded = true;
                    }
                    
                    resolve(content);
                }, 500);
            };
            
            reader.onerror = () => {
                reject(new Error('Ошибка чтения файла'));
            };
            
            reader.readAsText(file);
        });
    }
    
    // Извлечение имени парсера из грамматики
    extractParserName(grammarContent) {
        const match = grammarContent.match(/name\s*=\s*"([^"]+)"/);
        if (match && match[1]) {
            this.currentParserName = match[1];
        } else {
            this.currentParserName = 'yourtool';
        }
    }
    
    // Имитация генерации парсера
    generateParser() {
        return new Promise((resolve) => {
            // Имитация задержки генерации
            setTimeout(() => {
                console.log(`[Mock API] Парсер сгенерирован: ${this.currentParserName}`);
                console.log('[Mock API] Структура парсера:', {
                    name: this.currentParserName,
                    tokens: ['NUMBER', 'ID', 'STRING'],
                    rules: ['Program', 'Function', 'Statement', 'Expression'],
                    generatedAt: new Date().toISOString()
                });
                
                resolve({
                    success: true,
                    message: `Парсер "${this.currentParserName}" сгенерирован успешно!`,
                    parserName: this.currentParserName,
                    timestamp: new Date().toISOString()
                });
            }, 1500);
        });
    }
    
    // Имитация подключения интерпретатора
    connectInterpreter() {
        return new Promise((resolve) => {
            // Имитация задержки подключения
            setTimeout(() => {
                this.isInterpreterConnected = true;
                resolve({
                    success: true,
                    message: `Интерпретатор ${this.currentParserName} подключен`,
                    interpreter: this.currentParserName,
                    timestamp: new Date().toISOString()
                });
            }, 800);
        });
    }
    
    // Имитация выполнения программы
    runProgram(programCode) {
        return new Promise((resolve) => {
            // Имитация задержки выполнения
            setTimeout(() => {
                // Генерация мокового вывода
                this.programOutput = {
                    result: 42,
                    executionTime: '2.1ms',
                    variables: {
                        x: 10,
                        y: 32
                    },
                    output: 'Программа выполнена успешно',
                    timestamp: new Date().toISOString()
                };
                
                resolve({
                    success: true,
                    message: 'Программа успешно выполнена! Сгенерирован файл output.json',
                    output: this.programOutput,
                    downloadUrl: 'mock-data/output.json',
                    timestamp: new Date().toISOString()
                });
            }, 2000);
        });
    }
    
    // Имитация получения AST
    getAST() {
        return new Promise((resolve) => {
            // Имитация задержки запроса
            setTimeout(() => {
                resolve({
                    success: true,
                    message: 'AST сгенерирован',
                    imageUrl: 'images/mock-ast.png',
                    timestamp: new Date().toISOString()
                });
            }, 1000);
        });
    }
    
    // Создание мокового JSON файла для скачивания
    createMockOutputFile() {
        const output = {
            program: "func main() { return 42; }",
            result: 42,
            executionTime: "2.1ms",
            memoryUsage: "1.2MB",
            timestamp: new Date().toISOString(),
            generatedBy: "WebDSLCompiler Mock v1.0"
        };
        
        return JSON.stringify(output, null, 2);
    }
    
    // Показать уведомление
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'warning') icon = 'exclamation-triangle';
        
        notification.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        // Автоматическое скрытие через 5 секунд
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.mockAPI = new MockAPI();
});