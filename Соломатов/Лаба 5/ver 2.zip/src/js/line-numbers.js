/**
 * Line Numbers Module
 * Управление нумерацией строк для редакторов
 */

class LineNumbers {
    constructor() {
        this.codeEditor = document.getElementById('codeEditor');
        this.lineNumbers = document.getElementById('lineNumbers');
        
        this.init();
    }
    
    init() {
        if (!this.codeEditor || !this.lineNumbers) return;
        
        // Инициализация нумерации
        this.updateLineNumbers();
        
        // Обработчики событий для обновления нумерации
        this.codeEditor.addEventListener('input', () => this.updateLineNumbers());
        this.codeEditor.addEventListener('scroll', () => this.syncScroll());
        this.codeEditor.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                setTimeout(() => this.updateLineNumbers(), 0);
            }
        });
    }
    
    updateLineNumbers() {
        const lines = this.codeEditor.value.split('\n').length;
        const currentLines = this.lineNumbers.children.length;
        
        // Добавляем или удаляем строки при необходимости
        if (lines > currentLines) {
            for (let i = currentLines; i < lines; i++) {
                const lineDiv = document.createElement('div');
                lineDiv.textContent = i + 1;
                this.lineNumbers.appendChild(lineDiv);
            }
        } else if (lines < currentLines) {
            while (this.lineNumbers.children.length > lines) {
                this.lineNumbers.removeChild(this.lineNumbers.lastChild);
            }
        }
        
        // Обновляем номера строк
        Array.from(this.lineNumbers.children).forEach((div, index) => {
            div.textContent = index + 1;
        });
    }
    
    syncScroll() {
        // Синхронизация прокрутки редактора и номеров строк
        this.lineNumbers.scrollTop = this.codeEditor.scrollTop;
    }
    
    // Метод для принудительного обновления
    forceUpdate() {
        this.updateLineNumbers();
    }
}

// Инициализация после загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    window.lineNumbers = new LineNumbers();
});