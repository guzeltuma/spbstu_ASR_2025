/**
 * WebDSLCompiler - Основной файл с исправлениями
 */

document.addEventListener('DOMContentLoaded', () => {
    // Элементы DOM
    const modeSelect = document.getElementById('modeSelect');
    const developerActions = document.getElementById('developerActions');
    const userActions = document.getElementById('userActions');
    const editorTitle = document.getElementById('editorTitle');
    const editorStatus = document.getElementById('editorStatus');
    const codeEditor = document.getElementById('codeEditor');
    const lineNumbers = document.getElementById('lineNumbers');
    const syntaxOverlay = document.getElementById('syntaxOverlay');
    
    // Кнопки разработчика
    const loadGrammarBtn = document.getElementById('loadGrammarBtn');
    const generateParserBtn = document.getElementById('generateParserBtn');
    
    // Кнопки пользователя
    const connectInterpreterBtn = document.getElementById('connectInterpreterBtn');
    const loadProgramBtn = document.getElementById('loadProgramBtn');
    const runProgramBtn = document.getElementById('runProgramBtn');
    const runButtonText = runProgramBtn.querySelector('span');
    
    // Логи
    const compilationLog = document.getElementById('compilationLog');
    const interpretationLog = document.getElementById('interpretationLog');
    const compilationLogContainer = document.getElementById('compilationLogContainer');
    const interpretationLogContainer = document.getElementById('interpretationLogContainer');
    
    // File inputs
    const fileInputGrammar = document.getElementById('fileInputGrammar');
    const fileInputProgram = document.getElementById('fileInputProgram');
    
    // Результаты
    const resultsContent = document.getElementById('resultsContent');
    
    // Состояние приложения
    let currentMode = 'developer';
    let isInterpreterConnected = false;
    let currentGrammarContent = '';
    let currentProgramContent = '';
    let parserName = 'yourtool';
    
    // Инициализация
    init();
    
    function init() {
        setupEventListeners();
        switchMode('developer');
        updateLineNumbers();
        loadExampleGrammar();
    }
    
    function setupEventListeners() {
        // Переключение режимов
        modeSelect.addEventListener('change', (e) => {
            switchMode(e.target.value);
        });
        
        // Кнопки разработчика
        loadGrammarBtn.addEventListener('click', () => loadGrammar());
        generateParserBtn.addEventListener('click', () => generateInterpreter());
        
        // Кнопки пользователя
        connectInterpreterBtn.addEventListener('click', () => connectInterpreter());
        loadProgramBtn.addEventListener('click', () => loadProgram());
        runProgramBtn.addEventListener('click', () => runProgram());
        
        // File inputs
        fileInputGrammar.addEventListener('change', (e) => handleGrammarFile(e));
        fileInputProgram.addEventListener('change', (e) => handleProgramFile(e));
        
        // Обновление при вводе текста
        codeEditor.addEventListener('input', () => {
            updateLineNumbers();
            updateSyntaxHighlighting();
            if (currentMode === 'user') {
                updateRunButtonState();
            }
        });
        
        // Прокрутка номеров строк вместе с редактором
        codeEditor.addEventListener('scroll', () => {
            lineNumbers.scrollTop = codeEditor.scrollTop;
            syntaxOverlay.scrollTop = codeEditor.scrollTop;
            syntaxOverlay.scrollLeft = codeEditor.scrollLeft;
        });
        
        // Синхронизация размера
        codeEditor.addEventListener('resize', () => {
            updateOverlaySize();
        });
    }
    
    function switchMode(mode) {
        currentMode = mode;
        
        if (mode === 'developer') {
            // Показать режим разработчика
            developerActions.style.display = 'block';
            userActions.style.display = 'none';
            editorTitle.textContent = 'Редактор грамматики';
            editorStatus.textContent = 'Режим разработчика DSL: работа с грамматиками';
            
            // Показать лог компиляции
            compilationLogContainer.style.display = 'block';
            interpretationLogContainer.style.display = 'none';
            
            // Сбросить цвет редактора
            codeEditor.classList.remove('code-editor--error');
            
            // Очистить результаты
            clearResults();
            
            // Загрузить пример грамматики если редактор пустой
            if (!codeEditor.value.trim()) {
                loadExampleGrammar();
            }
            
            // Включить подсветку синтаксиса
            updateSyntaxHighlighting();
            
            // Показать оверлей подсветки
            syntaxOverlay.style.display = 'block';
            
        } else if (mode === 'user') {
            // Показать режим пользователя
            developerActions.style.display = 'none';
            userActions.style.display = 'block';
            editorTitle.textContent = 'Редактор DSL программы';
            editorStatus.textContent = 'Режим пользователя DSL: написание и выполнение программ';
            
            // Показать лог интерпретации
            compilationLogContainer.style.display = 'none';
            interpretationLogContainer.style.display = 'block';
            
            // Сбросить цвет редактора
            codeEditor.classList.remove('code-editor--error');
            
            // Очистить результаты
            clearResults();
            
            // Сбросить состояние интерпретатора
            isInterpreterConnected = false;
            connectInterpreterBtn.disabled = false;
            connectInterpreterBtn.innerHTML = '<i class="fas fa-plug"></i> Подключить DSL-интерпретатор';
            connectInterpreterBtn.classList.remove('btn--success');
            connectInterpreterBtn.classList.add('btn--primary');
            
            // Скрыть оверлей подсветки
            syntaxOverlay.style.display = 'none';
            syntaxOverlay.innerHTML = '';
            
            // Обновить состояние кнопки RUN
            updateRunButtonState();
            
            // Загрузить пример программы если редактор пустой
            if (!codeEditor.value.trim()) {
                loadExampleProgram();
            } else {
                // Очистить редактор если там старая грамматика
                const text = codeEditor.value;
                if (text.includes('METABLOCK') || text.includes('KEY') || text.includes('TERMINAL')) {
                    loadExampleProgram();
                }
            }
            
            updateLineNumbers();
        }
    }
    
    function loadExampleGrammar() {
        const exampleGrammar = `METABLOCK {
    name = "SimpleMathDSL"
    version = "1.0"
}

KEY 
    "func", "return", "if", "else"


TERMINAL 
    NUMBER: /[0-9]+(\\.[0-9]+)?/,
    ID: /[a-zA-Z_][a-zA-Z0-9_]*/,
    STRING: /"[^"]*"/


NON-TERMINAL 
    Program, Function, Statement, Expression


RULES 
    Program = Function*;
    Function = "func" ID "(" ")" "{" Statement* "}";
    Statement = "return" Expression ";";
    Expression = NUMBER | ID;`;
        
        codeEditor.value = exampleGrammar;
        updateSyntaxHighlighting();
    }
    
    function loadExampleProgram() {
        const exampleProgram = `// Пример программы на SimpleMathDSL

func main() {
    return 42;
}

func calculate() {
    return 10 + 5 * 2;
}

func greet(name) {
    return "Hello, " + name;
}`;
        
        codeEditor.value = exampleProgram;
    }
    
    function updateLineNumbers() {
        const lines = codeEditor.value.split('\n').length;
        let lineNumbersHtml = '';
        
        for (let i = 1; i <= lines; i++) {
            lineNumbersHtml += `<div>${i}</div>`;
        }
        
        lineNumbers.innerHTML = lineNumbersHtml;
    }
    
    function updateSyntaxHighlighting() {
        if (currentMode !== 'developer') return;
        
        const text = codeEditor.value;
        const keywords = ['KEY', 'TERMINAL', 'NON-TERMINAL', 'RULES', 'METABLOCK'];
        const keywordRegex = /\b(KEY|TERMINAL|NON\-TERMINAL|RULES|METABLOCK)\b/gi;
        
        // Разбиваем текст на строки
        const lines = text.split('\n');
        let highlightedHTML = '';
        
        lines.forEach((line, lineIndex) => {
            let lineHTML = '';
            let currentPos = 0;
            
            // Ищем ключевые слова в строке
            let match;
            while ((match = keywordRegex.exec(line)) !== null) {
                // Текст до ключевого слова
                const before = line.substring(currentPos, match.index);
                lineHTML += escapeHtml(before);
                
                // Ключевое слово
                lineHTML += `<span class="keyword-highlight">${match[0]}</span>`;
                
                currentPos = match.index + match[0].length;
            }
            
            // Остаток строки после последнего ключевого слова
            const after = line.substring(currentPos);
            lineHTML += escapeHtml(after);
            
            // Проверяем опечатки
            const words = line.split(/\s+/);
            words.forEach(word => {
                const cleanWord = word.replace(/[^\w\-]/g, '');
                if (isSimilarToKeyword(cleanWord, keywords) && !isExactKeyword(cleanWord, keywords)) {
                    // Находим позицию слова в строке
                    const wordIndex = line.indexOf(word);
                    if (wordIndex !== -1) {
                        // Заменяем слово на версию с подчеркиванием
                        const before = lineHTML.substring(0, wordIndex);
                        const after = lineHTML.substring(wordIndex + word.length);
                        lineHTML = before + `<span class="spellcheck-error">${cleanWord}</span>` + after;
                    }
                }
            });
            
            highlightedHTML += `<div>${lineHTML}</div>`;
        });
        
        syntaxOverlay.innerHTML = highlightedHTML;
        updateOverlaySize();
    }
    
    function updateOverlaySize() {
        // Синхронизируем размеры оверлея с текстовым полем
        syntaxOverlay.style.width = codeEditor.offsetWidth + 'px';
        syntaxOverlay.style.height = codeEditor.offsetHeight + 'px';
        syntaxOverlay.style.top = codeEditor.offsetTop + 'px';
        syntaxOverlay.style.left = codeEditor.offsetLeft + 'px';
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function isSimilarToKeyword(word, keywords) {
        if (!word || word.length < 3) return false;
        
        const upperWord = word.toUpperCase();
        return keywords.some(keyword => {
            // Простая проверка расстояния (максимум 2 ошибки)
            return levenshteinDistance(upperWord, keyword) <= 2;
        });
    }
    
    function isExactKeyword(word, keywords) {
        const upperWord = word.toUpperCase();
        return keywords.includes(upperWord);
    }
    
    function levenshteinDistance(a, b) {
        if (a.length === 0) return b.length;
        if (b.length === 0) return a.length;
        
        const matrix = [];
        
        for (let i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }
        
        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }
        
        return matrix[b.length][a.length];
    }
    
    function loadGrammar() {
        fileInputGrammar.click();
    }
    
    function handleGrammarFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target.result;
            codeEditor.value = content;
            currentGrammarContent = content;
            updateLineNumbers();
            updateSyntaxHighlighting();
            
            // Извлечь имя парсера
            extractParserName(content);
            
            addCompilationLog(`Грамматика "${file.name}" загружена`, 'success');
            showNotification(`Грамматика "${file.name}" загружена`, 'success');
        };
        reader.readAsText(file);
        
        // Сбросить input
        event.target.value = '';
    }
    
    function extractParserName(content) {
        const match = content.match(/name\s*=\s*"([^"]+)"/);
        if (match && match[1]) {
            parserName = match[1];
        } else {
            parserName = 'yourtool';
        }
        return parserName;
    }
    
    async function generateInterpreter() {
        // Сбросить цвет редактора
        codeEditor.classList.remove('code-editor--error');
        
        // Проверить наличие обязательных блоков
        const validation = validateGrammarBlocks(codeEditor.value);
        
        // Показать лог компиляции
        compilationLog.innerHTML = '';
        addCompilationLog('Начинаем проверку грамматики...', 'info');
        
        // Имитация задержки
        generateParserBtn.disabled = true;
        generateParserBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Проверка...';
        
        setTimeout(async () => {
            if (!validation.hasAllBlocks) {
                // Ошибка: не все блоки присутствуют
                addCompilationLog(`✗ Ошибка: отсутствует блок ${validation.missingBlocks[0]}`, 'error');
                
                // Красный фон редактора
                codeEditor.classList.add('code-editor--error');
                
                showNotification(`Ошибка: отсутствует блок ${validation.missingBlocks[0]}`, 'error');
            } else {
                // Все блоки присутствуют
                addCompilationLog('✓ Все обязательные блоки присутствуют', 'success');
                addCompilationLog('✓ Грамматика валидна', 'success');
                addCompilationLog('Генерация файлов интерпретатора...', 'info');
                
                // Генерируем ZIP
                const zipResult = await generateInterpreterZip();
                
                if (zipResult.success) {
                    addCompilationLog(`✓ Интерпретатор "${parserName}" успешно сгенерирован`, 'success');
                    
                    // Создать кнопку для скачивания ZIP
                    createDownloadZipButton(zipResult.fileName, zipResult.url);
                    
                    showNotification(`Интерпретатор "${parserName}" сгенерирован`, 'success');
                } else {
                    addCompilationLog(`✗ Ошибка генерации: ${zipResult.error}`, 'error');
                    showNotification(`Ошибка генерации: ${zipResult.error}`, 'error');
                }
            }
            
            // Восстановить кнопку
            generateParserBtn.disabled = false;
            generateParserBtn.innerHTML = '<i class="fas fa-cogs"></i> Сгенерировать интерпретатор';
            
        }, 1500);
    }
    
    async function generateInterpreterZip() {
        try {
            const zip = new JSZip();
            
            // Добавляем файлы
            zip.file("grammar.py", generateGrammarFile());
            zip.file("tokenizer.py", generateTokenizerFile());
            zip.file("cst_builder.py", generateCSTBuilderFile());
            
            const semhandlers = zip.folder("semhandlers");
            semhandlers.file("__init__.py", generateInitFile());
            semhandlers.file("visitor.py", generateVisitorFile());
            
            zip.file("README.md", generateReadmeFile());
            
            // Генерируем ZIP
            const content = await zip.generateAsync({
                type: "blob",
                compression: "DEFLATE",
                compressionOptions: {
                    level: 6
                }
            });
            
            // Создаем URL для скачивания
            const url = URL.createObjectURL(content);
            
            return {
                success: true,
                fileName: `${parserName}_interpreter.zip`,
                url: url
            };
            
        } catch (error) {
            console.error('Error generating ZIP:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    function generateGrammarFile() {
        return `# Grammar file for ${parserName} interpreter
# Generated by WebDSLCompiler

class Grammar:
    def __init__(self):
        self.rules = {}
        self.start_symbol = 'Program'
    
    def parse(self, tokens):
        # Mock parsing logic
        return {'type': 'Program', 'children': []}
    
    def validate(self):
        # Mock validation
        return True`;
    }
    
    function generateTokenizerFile() {
        return `# Tokenizer file for ${parserName} interpreter
# Generated by WebDSLCompiler

import re

class Tokenizer:
    def __init__(self):
        self.token_patterns = [
            (r'\\\\s+', None),  # Whitespace
            (r'[0-9]+', 'NUMBER'),
            (r'[a-zA-Z_][a-zA-Z0-9_]*', 'IDENTIFIER'),
            (r'"[^"]*"', 'STRING')
        ]
    
    def tokenize(self, code):
        # Mock tokenization
        tokens = []
        lines = code.split('\\\\n')
        for line in lines:
            tokens.append({'type': 'LINE', 'value': line})
        return tokens`;
    }
    
    function generateCSTBuilderFile() {
        return `# CST Builder file for ${parserName} interpreter
# Generated by WebDSLCompiler

class CSTNode:
    def __init__(self, type, value=None):
        self.type = type
        self.value = value
        self.children = []
    
    def add_child(self, child):
        self.children.append(child)

class CSTBuilder:
    def __init__(self):
        self.root = CSTNode('Program')
    
    def build(self, tokens):
        # Mock CST building
        return self.root`;
    }
    
    function generateInitFile() {
        return `# Semantic handlers package for ${parserName}
# Generated by WebDSLCompiler

from .visitor import SemanticVisitor

__all__ = ['SemanticVisitor']`;
    }
    
    function generateVisitorFile() {
        return `# Semantic visitor for ${parserName} interpreter
# Generated by WebDSLCompiler

class SemanticVisitor:
    def __init__(self):
        self.symbol_table = {}
        self.errors = []
    
    def visit(self, node):
        # Mock visitor pattern
        method_name = f'visit_{node.type}'
        if hasattr(self, method_name):
            return getattr(self, method_name)(node)
        else:
            return self.generic_visit(node)
    
    def generic_visit(self, node):
        for child in node.children:
            self.visit(child)
    
    def visit_Program(self, node):
        self.generic_visit(node)
        return {'success': True, 'result': 'Program executed successfully'}`;
    }
    
    function generateReadmeFile() {
        return `# ${parserName} Interpreter

This interpreter was generated by WebDSLCompiler.

## Files
- grammar.py: Contains grammar rules and parsing logic
- tokenizer.py: Tokenizes input code
- cst_builder.py: Builds Concrete Syntax Tree
- semhandlers/: Semantic analysis handlers

## Usage
1. Import the modules
2. Tokenize your code
3. Parse tokens into CST
4. Apply semantic analysis

Generated on: ${new Date().toISOString()}`;
    }
    
    function validateGrammarBlocks(content) {
        const keywords = ['KEY', 'TERMINAL', 'NON-TERMINAL', 'RULES', 'METABLOCK'];
        const foundBlocks = [];
        const lines = content.split('\n');
        
        lines.forEach(line => {
            const upperLine = line.toUpperCase();
            keywords.forEach(keyword => {
                if (upperLine.includes(keyword) && !foundBlocks.includes(keyword)) {
                    foundBlocks.push(keyword);
                }
            });
        });
        
        const missingBlocks = keywords.filter(keyword => !foundBlocks.includes(keyword));
        
        return {
            hasAllBlocks: missingBlocks.length === 0,
            missingBlocks: missingBlocks,
            foundBlocks: foundBlocks
        };
    }
    
    function createDownloadZipButton(fileName, url) {
        // Удалить старую кнопку если есть
        const oldButton = resultsContent.querySelector('.zip-download-btn');
        if (oldButton) {
            oldButton.remove();
        }
        
        // Создать новую кнопку
        const button = document.createElement('button');
        button.className = 'btn btn--primary zip-download-btn';
        button.innerHTML = `<i class="fas fa-download"></i> Скачать ${fileName}`;
        
        button.addEventListener('click', () => {
            // Скачать ZIP
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            
            // Очистка
            setTimeout(() => {
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
            
            addCompilationLog(`✓ ZIP-архив "${fileName}" скачан`, 'success');
            showNotification(`ZIP-архив "${fileName}" скачан`, 'success');
            
            // Обновить кнопку
            button.innerHTML = `<i class="fas fa-check"></i> ${fileName} скачан`;
            button.classList.remove('btn--primary');
            button.classList.add('btn--success');
            
            // Через 3 секунды вернуть исходное состояние
            setTimeout(() => {
                button.innerHTML = `<i class="fas fa-download"></i> Скачать ${fileName}`;
                button.classList.remove('btn--success');
                button.classList.add('btn--primary');
            }, 3000);
        });
        
        resultsContent.appendChild(button);
    }
    
    function connectInterpreter() {
        // Имитация подключения интерпретатора
        connectInterpreterBtn.disabled = true;
        connectInterpreterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Подключение...';
        
        setTimeout(() => {
            // Моковая валидация структуры
            const validation = validateInterpreterStructure();
            
            if (validation.isValid) {
                isInterpreterConnected = true;
                addInterpretationLog(`Интерпретатор "${parserName}" успешно подключен`, 'success');
                showNotification(`Интерпретатор "${parserName}" подключен`, 'success');
                
                // Обновить кнопку
                connectInterpreterBtn.innerHTML = `<i class="fas fa-check"></i> Интерпретатор подключен`;
                connectInterpreterBtn.classList.remove('btn--primary');
                connectInterpreterBtn.classList.add('btn--success');
                
                // Обновить кнопку RUN
                updateRunButtonState();
            } else {
                addInterpretationLog('Ошибка: неверная структура интерпретатора', 'error');
                showNotification('Ошибка: неверная структура интерпретатора', 'error');
                
                connectInterpreterBtn.innerHTML = '<i class="fas fa-plug"></i> Подключить DSL-интерпретатор';
                connectInterpreterBtn.disabled = false;
            }
        }, 1000);
    }
    
    function validateInterpreterStructure() {
        // В мок-версии всегда возвращаем true
        return {
            isValid: true,
            missingFiles: [],
            message: 'Структура интерпретатора корректна'
        };
    }
    
    function loadProgram() {
        fileInputProgram.click();
    }
    
    function handleProgramFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target.result;
            codeEditor.value = content;
            currentProgramContent = content;
            updateLineNumbers();
            
            addInterpretationLog(`Программа "${file.name}" загружена`, 'success');
            showNotification(`Программа "${file.name}" загружена`, 'success');
            
            // Обновить состояние кнопки RUN
            updateRunButtonState();
        };
        reader.readAsText(file);
        
        // Сбросить input
        event.target.value = '';
    }
    
    function updateRunButtonState() {
        const isProgramEmpty = !codeEditor.value.trim();
        
        if (isProgramEmpty || !isInterpreterConnected) {
            // Серая неактивная кнопка
            runProgramBtn.disabled = true;
            runProgramBtn.classList.remove('btn--success');
            runProgramBtn.classList.add('btn--disabled');
        } else {
            // Зеленая активная кнопка
            runProgramBtn.disabled = false;
            runProgramBtn.classList.remove('btn--disabled');
            runProgramBtn.classList.add('btn--success');
        }
    }
    
    function runProgram() {
        if (!isInterpreterConnected || !codeEditor.value.trim()) return;
        
        // Имитация выполнения программы
        runProgramBtn.disabled = true;
        runProgramBtn.classList.remove('btn--success');
        runProgramBtn.classList.add('btn--disabled');
        runButtonText.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Выполнение...';
        
        // Очистить лог интерпретации
        interpretationLog.innerHTML = '';
        addInterpretationLog('Начинаем компилировать...', 'info');
        
        setTimeout(() => {
            addInterpretationLog('Обращаемся к интерпретатору...', 'info');
        }, 500);
        
        setTimeout(() => {
            addInterpretationLog('Вывод: return 0', 'info');
        }, 1000);
        
        setTimeout(() => {
            addInterpretationLog('Программа выполнена успешно', 'success');
            
            // Восстановить кнопку
            updateRunButtonState();
            runButtonText.innerHTML = 'RUN';
            
            // Показать результаты
            showResults();
            
            showNotification('Программа выполнена успешно', 'success');
        }, 1500);
    }
    
    function showResults() {
        resultsContent.innerHTML = '';
        
        // Добавить сообщение об успехе
        const successMessage = document.createElement('div');
        successMessage.className = 'result-item result-item--success';
        successMessage.innerHTML = '<i class="fas fa-check"></i> Программа успешно выполнена! Сгенерирован файл output.json';
        resultsContent.appendChild(successMessage);
        
        // Добавить ссылку для скачивания
        const downloadLink = document.createElement('a');
        downloadLink.className = 'download-link';
        downloadLink.href = '#';
        downloadLink.innerHTML = '<i class="fas fa-download"></i> output.json';
        
        downloadLink.addEventListener('click', (e) => {
            e.preventDefault();
            downloadOutputJSON();
        });
        
        resultsContent.appendChild(downloadLink);
    }
    
    function downloadOutputJSON() {
        const output = {
            program: codeEditor.value,
            result: 0,
            executionTime: "1.5ms",
            timestamp: new Date().toISOString(),
            interpreter: parserName
        };
        
        const jsonString = JSON.stringify(output, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'output.json';
        document.body.appendChild(a);
        a.click();
        
        // Очистка
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
        
        showNotification('Файл output.json скачан', 'success');
    }
    
    function addCompilationLog(message, type = 'info') {
        const logLine = document.createElement('div');
        logLine.className = `log-line log-line--${type}`;
        
        let prefix = 'ℹ';
        if (type === 'error') prefix = '✗';
        if (type === 'success') prefix = '✓';
        
        logLine.textContent = `${prefix} ${message}`;
        compilationLog.appendChild(logLine);
        
        // Автопрокрутка
        compilationLog.scrollTop = compilationLog.scrollHeight;
    }
    
    function addInterpretationLog(message, type = 'info') {
        const logLine = document.createElement('div');
        logLine.className = `log-line log-line--${type}`;
        
        let prefix = '→';
        if (type === 'error') prefix = '✗';
        if (type === 'success') prefix = '✓';
        
        logLine.textContent = `${prefix} ${message}`;
        interpretationLog.appendChild(logLine);
        
        // Автопрокрутка
        interpretationLog.scrollTop = interpretationLog.scrollHeight;
    }
    
    function clearResults() {
        resultsContent.innerHTML = '';
    }
    
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        
        notification.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        // Автоматическое скрытие
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
});